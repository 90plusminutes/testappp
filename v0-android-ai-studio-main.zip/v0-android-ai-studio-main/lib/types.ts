export interface Message {
  id: string
  role: "user" | "assistant" | "system"
  content: string
  timestamp: Date
  model?: string
}

export interface Chat {
  id: string
  title: string
  messages: Message[]
  createdAt: Date
  updatedAt: Date
}

export interface CodeSnippet {
  id: string
  title: string
  code: string
  language: string
  createdAt: Date
}

export interface AIModel {
  id: string
  name: string
  provider: string
  description: string
}

export interface WorkflowStep {
  id: string
  type: "chat" | "code" | "summarize" | "image"
  config: any
  order: number
}

export interface Workflow {
  id: string
  name: string
  description: string
  steps: WorkflowStep[]
  createdAt: Date
}

export interface Tool {
  id: string
  name: string
  description: string
  icon: string
  category: "analysis" | "generation" | "code" | "workflow"
}
