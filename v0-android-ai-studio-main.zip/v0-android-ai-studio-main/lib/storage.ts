import type { Chat, CodeSnippet, Workflow } from "./types"

// Local storage utilities for data persistence
export const storage = {
  // Chats
  getChats: (): Chat[] => {
    if (typeof window === "undefined") return []
    const chats = localStorage.getItem("ai-studio-chats")
    return chats ? JSON.parse(chats) : []
  },

  saveChat: (chat: Chat) => {
    if (typeof window === "undefined") return
    const chats = storage.getChats()
    const index = chats.findIndex((c) => c.id === chat.id)
    if (index >= 0) {
      chats[index] = chat
    } else {
      chats.unshift(chat)
    }
    localStorage.setItem("ai-studio-chats", JSON.stringify(chats))
  },

  deleteChat: (id: string) => {
    if (typeof window === "undefined") return
    const chats = storage.getChats().filter((c) => c.id !== id)
    localStorage.setItem("ai-studio-chats", JSON.stringify(chats))
  },

  // Code Snippets
  getSnippets: (): CodeSnippet[] => {
    if (typeof window === "undefined") return []
    const snippets = localStorage.getItem("ai-studio-snippets")
    return snippets ? JSON.parse(snippets) : []
  },

  saveSnippet: (snippet: CodeSnippet) => {
    if (typeof window === "undefined") return
    const snippets = storage.getSnippets()
    const index = snippets.findIndex((s) => s.id === snippet.id)
    if (index >= 0) {
      snippets[index] = snippet
    } else {
      snippets.unshift(snippet)
    }
    localStorage.setItem("ai-studio-snippets", JSON.stringify(snippets))
  },

  deleteSnippet: (id: string) => {
    if (typeof window === "undefined") return
    const snippets = storage.getSnippets().filter((s) => s.id !== id)
    localStorage.setItem("ai-studio-snippets", JSON.stringify(snippets))
  },

  // Workflows
  getWorkflows: (): Workflow[] => {
    if (typeof window === "undefined") return []
    const workflows = localStorage.getItem("ai-studio-workflows")
    return workflows ? JSON.parse(workflows) : []
  },

  saveWorkflow: (workflow: Workflow) => {
    if (typeof window === "undefined") return
    const workflows = storage.getWorkflows()
    const index = workflows.findIndex((w) => w.id === workflow.id)
    if (index >= 0) {
      workflows[index] = workflow
    } else {
      workflows.unshift(workflow)
    }
    localStorage.setItem("ai-studio-workflows", JSON.stringify(workflows))
  },

  deleteWorkflow: (id: string) => {
    if (typeof window === "undefined") return
    const workflows = storage.getWorkflows().filter((w) => w.id !== id)
    localStorage.setItem("ai-studio-workflows", JSON.stringify(workflows))
  },
}
