import type { AIModel } from "./types"

export const AI_MODELS: AIModel[] = [
  {
    id: "openai/gpt-4o",
    name: "GPT-4o",
    provider: "OpenAI",
    description: "Most capable model for complex tasks",
  },
  {
    id: "openai/gpt-4o-mini",
    name: "GPT-4o Mini",
    provider: "OpenAI",
    description: "Fast and efficient for everyday tasks",
  },
  {
    id: "anthropic/claude-3-5-sonnet-20241022",
    name: "Claude 3.5 Sonnet",
    provider: "Anthropic",
    description: "Excellent for coding and analysis",
  },
  {
    id: "anthropic/claude-3-5-haiku-20241022",
    name: "Claude 3.5 Haiku",
    provider: "Anthropic",
    description: "Fast responses with good quality",
  },
  {
    id: "xai/grok-beta",
    name: "Grok",
    provider: "xAI",
    description: "Real-time knowledge and creativity",
  },
]

export const getModelById = (id: string) => {
  return AI_MODELS.find((model) => model.id === id) || AI_MODELS[0]
}
