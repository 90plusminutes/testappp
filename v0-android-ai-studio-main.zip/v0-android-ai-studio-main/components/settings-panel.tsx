"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { Trash2 } from "lucide-react"
import { toast } from "@/hooks/use-toast"

export function SettingsPanel() {
  const clearAllData = () => {
    if (confirm("Are you sure? This will delete all chats, snippets, and workflows.")) {
      localStorage.clear()
      toast({
        title: "Cleared",
        description: "All data has been cleared",
      })
    }
  }

  return (
    <div className="flex h-full flex-col">
      <div className="border-b p-4">
        <h2 className="font-semibold">Settings</h2>
        <p className="text-sm text-muted-foreground">Customize your AI Studio experience</p>
      </div>

      <div className="flex-1 p-4 overflow-auto">
        <div className="max-w-2xl mx-auto space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Appearance</CardTitle>
              <CardDescription>Customize the look and feel</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Dark Mode</Label>
                  <p className="text-sm text-muted-foreground">Toggle dark/light theme</p>
                </div>
                <Switch />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>AI Models</CardTitle>
              <CardDescription>Configure default AI models</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Default Chat Model</Label>
                <p className="text-sm text-muted-foreground">GPT-4o Mini</p>
              </div>
              <div className="space-y-2">
                <Label>Default Code Model</Label>
                <p className="text-sm text-muted-foreground">Claude 3.5 Sonnet</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Data Management</CardTitle>
              <CardDescription>Manage your stored data</CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="destructive" onClick={clearAllData}>
                <Trash2 className="h-4 w-4 mr-2" />
                Clear All Data
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>About</CardTitle>
              <CardDescription>AI Studio information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <div>
                <Label>Version</Label>
                <p className="text-sm text-muted-foreground">1.0.0</p>
              </div>
              <div>
                <Label>Features</Label>
                <ul className="text-sm text-muted-foreground list-disc list-inside space-y-1">
                  <li>Multi-model AI chat</li>
                  <li>Code generation and debugging</li>
                  <li>Document analysis</li>
                  <li>Workflow automation</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
