"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { FileText, ImageIcon, Sparkles, Loader2 } from "lucide-react"
import { toast } from "@/hooks/use-toast"

export function AITools() {
  const [documentText, setDocumentText] = useState("")
  const [analysisType, setAnalysisType] = useState("summary")
  const [result, setResult] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)

  const analyzeDocument = async () => {
    if (!documentText.trim()) return

    setIsProcessing(true)
    try {
      const response = await fetch("/api/analyze-document", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: documentText,
          analysisType,
          model: "openai/gpt-4o-mini",
        }),
      })

      const data = await response.json()
      setResult(data.analysis)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to analyze document",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const tools = [
    {
      id: "document",
      name: "Document Analyzer",
      description: "Analyze and extract insights from documents",
      icon: FileText,
    },
    {
      id: "image",
      name: "Image Generator",
      description: "Generate images with AI (Coming Soon)",
      icon: ImageIcon,
    },
    {
      id: "enhance",
      name: "Text Enhancer",
      description: "Improve and enhance your writing (Coming Soon)",
      icon: Sparkles,
    },
  ]

  return (
    <div className="flex h-full flex-col">
      <div className="border-b p-4">
        <h2 className="font-semibold">AI Tools Suite</h2>
        <p className="text-sm text-muted-foreground">Powerful AI tools for analysis and generation</p>
      </div>

      <div className="flex-1 p-4 overflow-auto">
        <div className="max-w-5xl mx-auto">
          <Tabs defaultValue="document">
            <TabsList className="grid w-full grid-cols-3">
              {tools.map((tool) => {
                const Icon = tool.icon
                return (
                  <TabsTrigger key={tool.id} value={tool.id}>
                    <Icon className="h-4 w-4 mr-2" />
                    {tool.name}
                  </TabsTrigger>
                )
              })}
            </TabsList>

            <TabsContent value="document" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Document Analyzer</CardTitle>
                  <CardDescription>Paste your document and choose an analysis type</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Select value={analysisType} onValueChange={setAnalysisType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="summary">Summary</SelectItem>
                      <SelectItem value="sentiment">Sentiment Analysis</SelectItem>
                      <SelectItem value="keywords">Keyword Extraction</SelectItem>
                      <SelectItem value="questions">Q&A Generation</SelectItem>
                    </SelectContent>
                  </Select>

                  <Textarea
                    value={documentText}
                    onChange={(e) => setDocumentText(e.target.value)}
                    placeholder="Paste your document here..."
                    className="min-h-[200px]"
                  />

                  <Button onClick={analyzeDocument} disabled={isProcessing || !documentText.trim()}>
                    {isProcessing ? (
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    ) : (
                      <FileText className="h-4 w-4 mr-2" />
                    )}
                    Analyze Document
                  </Button>

                  {result && (
                    <Card className="bg-muted">
                      <CardContent className="pt-4">
                        <h4 className="font-medium mb-2">Analysis Result:</h4>
                        <pre className="whitespace-pre-wrap text-sm">{result}</pre>
                      </CardContent>
                    </Card>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="image" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Image Generator</CardTitle>
                  <CardDescription>Coming soon - Generate images with AI</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12 text-muted-foreground">
                    <ImageIcon className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Image generation feature will be available soon</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="enhance" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle>Text Enhancer</CardTitle>
                  <CardDescription>Coming soon - Enhance your writing with AI</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12 text-muted-foreground">
                    <Sparkles className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Text enhancement feature will be available soon</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
