"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Plus, Play, Save, Trash2 } from "lucide-react"
import { storage } from "@/lib/storage"
import { toast } from "@/hooks/use-toast"
import type { Workflow, WorkflowStep } from "@/lib/types"

export function WorkflowBuilder() {
  const [workflows, setWorkflows] = useState<Workflow[]>(() => storage.getWorkflows())
  const [currentWorkflow, setCurrentWorkflow] = useState<Workflow | null>(null)
  const [workflowName, setWorkflowName] = useState("")
  const [workflowDescription, setWorkflowDescription] = useState("")

  const createNewWorkflow = () => {
    const newWorkflow: Workflow = {
      id: Date.now().toString(),
      name: workflowName || "New Workflow",
      description: workflowDescription || "",
      steps: [],
      createdAt: new Date(),
    }
    setCurrentWorkflow(newWorkflow)
    setWorkflowName("")
    setWorkflowDescription("")
  }

  const addStep = (type: WorkflowStep["type"]) => {
    if (!currentWorkflow) return

    const newStep: WorkflowStep = {
      id: Date.now().toString(),
      type,
      config: {},
      order: currentWorkflow.steps.length,
    }

    setCurrentWorkflow({
      ...currentWorkflow,
      steps: [...currentWorkflow.steps, newStep],
    })
  }

  const removeStep = (stepId: string) => {
    if (!currentWorkflow) return

    setCurrentWorkflow({
      ...currentWorkflow,
      steps: currentWorkflow.steps.filter((s) => s.id !== stepId),
    })
  }

  const saveWorkflow = () => {
    if (!currentWorkflow) return

    storage.saveWorkflow(currentWorkflow)
    setWorkflows(storage.getWorkflows())
    setCurrentWorkflow(null)

    toast({
      title: "Saved",
      description: "Workflow saved successfully",
    })
  }

  const deleteWorkflow = (id: string) => {
    storage.deleteWorkflow(id)
    setWorkflows(storage.getWorkflows())

    toast({
      title: "Deleted",
      description: "Workflow deleted",
    })
  }

  const stepTypes = [
    { id: "chat", name: "AI Chat", description: "Send a prompt to AI" },
    { id: "code", name: "Generate Code", description: "Generate code with AI" },
    { id: "summarize", name: "Summarize", description: "Summarize text" },
    { id: "image", name: "Generate Image", description: "Create an image" },
  ]

  return (
    <div className="flex h-full flex-col">
      <div className="border-b p-4">
        <h2 className="font-semibold">Workflow Automation</h2>
        <p className="text-sm text-muted-foreground">Chain AI tasks into automated workflows</p>
      </div>

      <div className="flex-1 p-4 overflow-auto">
        <div className="max-w-5xl mx-auto space-y-4">
          {!currentWorkflow ? (
            <>
              <Card>
                <CardHeader>
                  <CardTitle>Create New Workflow</CardTitle>
                  <CardDescription>Build automated AI task sequences</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="workflow-name">Workflow Name</Label>
                    <Input
                      id="workflow-name"
                      value={workflowName}
                      onChange={(e) => setWorkflowName(e.target.value)}
                      placeholder="e.g., Code Review Assistant"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="workflow-desc">Description</Label>
                    <Input
                      id="workflow-desc"
                      value={workflowDescription}
                      onChange={(e) => setWorkflowDescription(e.target.value)}
                      placeholder="What does this workflow do?"
                    />
                  </div>
                  <Button onClick={createNewWorkflow}>
                    <Plus className="h-4 w-4 mr-2" />
                    Create Workflow
                  </Button>
                </CardContent>
              </Card>

              <div className="space-y-2">
                <h3 className="text-sm font-medium">Saved Workflows</h3>
                {workflows.length === 0 ? (
                  <Card>
                    <CardContent className="text-center py-8 text-muted-foreground">
                      No workflows yet. Create your first workflow above.
                    </CardContent>
                  </Card>
                ) : (
                  workflows.map((workflow) => (
                    <Card key={workflow.id}>
                      <CardContent className="flex items-center justify-between p-4">
                        <div>
                          <h4 className="font-medium">{workflow.name}</h4>
                          <p className="text-sm text-muted-foreground">{workflow.description}</p>
                          <p className="text-xs text-muted-foreground mt-1">{workflow.steps.length} steps</p>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline">
                            <Play className="h-4 w-4 mr-2" />
                            Run
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => deleteWorkflow(workflow.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </>
          ) : (
            <>
              <Card>
                <CardHeader>
                  <CardTitle>{currentWorkflow.name}</CardTitle>
                  <CardDescription>{currentWorkflow.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium mb-2">Add Step</h4>
                    <div className="flex gap-2 flex-wrap">
                      {stepTypes.map((type) => (
                        <Button
                          key={type.id}
                          variant="outline"
                          size="sm"
                          onClick={() => addStep(type.id as WorkflowStep["type"])}
                        >
                          <Plus className="h-3 w-3 mr-2" />
                          {type.name}
                        </Button>
                      ))}
                    </div>
                  </div>

                  {currentWorkflow.steps.length > 0 && (
                    <div className="space-y-2">
                      <h4 className="text-sm font-medium">Workflow Steps</h4>
                      {currentWorkflow.steps.map((step, index) => (
                        <Card key={step.id}>
                          <CardContent className="flex items-center justify-between p-3">
                            <div className="flex items-center gap-3">
                              <div className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs font-medium">
                                {index + 1}
                              </div>
                              <div>
                                <p className="font-medium text-sm">{stepTypes.find((t) => t.id === step.type)?.name}</p>
                                <p className="text-xs text-muted-foreground">
                                  {stepTypes.find((t) => t.id === step.type)?.description}
                                </p>
                              </div>
                            </div>
                            <Button size="sm" variant="ghost" onClick={() => removeStep(step.id)}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}

                  <div className="flex gap-2">
                    <Button onClick={saveWorkflow}>
                      <Save className="h-4 w-4 mr-2" />
                      Save Workflow
                    </Button>
                    <Button variant="outline" onClick={() => setCurrentWorkflow(null)}>
                      Cancel
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
