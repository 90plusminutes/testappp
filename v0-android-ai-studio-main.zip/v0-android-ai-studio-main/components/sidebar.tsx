"use client"

import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { MessageSquare, Code, Wrench, Workflow, Settings, Plus, Trash2 } from "lucide-react"
import { cn } from "@/lib/utils"

interface SidebarProps {
  activeView: string
  onViewChange: (view: string) => void
  chats?: any[]
  onNewChat?: () => void
  onSelectChat?: (id: string) => void
  onDeleteChat?: (id: string) => void
  selectedChatId?: string
}

export function Sidebar({
  activeView,
  onViewChange,
  chats = [],
  onNewChat,
  onSelectChat,
  onDeleteChat,
  selectedChatId,
}: SidebarProps) {
  const navItems = [
    { id: "chat", label: "AI Chat", icon: MessageSquare },
    { id: "code", label: "Code Editor", icon: Code },
    { id: "tools", label: "AI Tools", icon: Wrench },
    { id: "workflow", label: "Workflows", icon: Workflow },
    { id: "settings", label: "Settings", icon: Settings },
  ]

  return (
    <div className="flex h-full flex-col border-r bg-muted/30">
      <div className="border-b p-4">
        <h1 className="text-lg font-semibold text-balance">AI Studio</h1>
        <p className="text-xs text-muted-foreground">Professional Development</p>
      </div>

      <ScrollArea className="flex-1">
        <div className="space-y-1 p-2">
          {navItems.map((item) => {
            const Icon = item.icon
            return (
              <Button
                key={item.id}
                variant={activeView === item.id ? "secondary" : "ghost"}
                className="w-full justify-start gap-2"
                onClick={() => onViewChange(item.id)}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </Button>
            )
          })}
        </div>

        {activeView === "chat" && (
          <div className="mt-4 border-t p-2">
            <div className="mb-2 flex items-center justify-between px-2">
              <span className="text-xs font-medium text-muted-foreground">Recent Chats</span>
              <Button size="icon" variant="ghost" className="h-6 w-6" onClick={onNewChat}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <div className="space-y-1">
              {chats.map((chat) => (
                <div
                  key={chat.id}
                  className={cn(
                    "group flex items-center gap-2 rounded-md px-2 py-1.5 text-sm hover:bg-accent cursor-pointer",
                    selectedChatId === chat.id && "bg-accent",
                  )}
                  onClick={() => onSelectChat?.(chat.id)}
                >
                  <MessageSquare className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                  <span className="flex-1 truncate">{chat.title}</span>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="h-6 w-6 opacity-0 group-hover:opacity-100"
                    onClick={(e) => {
                      e.stopPropagation()
                      onDeleteChat?.(chat.id)
                    }}
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}
      </ScrollArea>
    </div>
  )
}
