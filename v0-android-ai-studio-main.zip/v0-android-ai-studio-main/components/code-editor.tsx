"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card } from "@/components/ui/card"
import { Wand2, Bug, Save, Loader2 } from "lucide-react"
import { toast } from "@/hooks/use-toast"
import { storage } from "@/lib/storage"

const LANGUAGES = [
  { id: "typescript", name: "TypeScript" },
  { id: "javascript", name: "JavaScript" },
  { id: "python", name: "Python" },
  { id: "java", name: "Java" },
  { id: "cpp", name: "C++" },
  { id: "rust", name: "Rust" },
  { id: "go", name: "Go" },
]

export function CodeEditor() {
  const [language, setLanguage] = useState("typescript")
  const [code, setCode] = useState("")
  const [prompt, setPrompt] = useState("")
  const [output, setOutput] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [isDebugging, setIsDebugging] = useState(false)

  const generateCode = async () => {
    if (!prompt.trim()) return

    setIsGenerating(true)
    try {
      const response = await fetch("/api/generate-code", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, language, model: "openai/gpt-4o-mini" }),
      })

      const data = await response.json()
      setCode(data.code)
      setOutput("Code generated successfully!")
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate code",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const debugCode = async () => {
    if (!code.trim()) return

    setIsDebugging(true)
    try {
      const response = await fetch("/api/debug-code", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code, language, model: "openai/gpt-4o-mini" }),
      })

      const data = await response.json()
      setOutput(data.analysis)
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to debug code",
        variant: "destructive",
      })
    } finally {
      setIsDebugging(false)
    }
  }

  const saveSnippet = () => {
    if (!code.trim()) return

    const snippet = {
      id: Date.now().toString(),
      title: prompt || `${language} snippet`,
      code,
      language,
      createdAt: new Date(),
    }

    storage.saveSnippet(snippet)
    toast({
      title: "Saved",
      description: "Code snippet saved successfully",
    })
  }

  return (
    <div className="flex h-full flex-col">
      <div className="border-b p-4">
        <h2 className="font-semibold">Code Editor</h2>
        <p className="text-sm text-muted-foreground">Generate, edit, and debug code with AI</p>
      </div>

      <div className="flex-1 p-4 overflow-auto">
        <div className="max-w-5xl mx-auto space-y-4">
          <Card className="p-4">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Select value={language} onValueChange={setLanguage}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {LANGUAGES.map((lang) => (
                      <SelectItem key={lang.id} value={lang.id}>
                        {lang.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button onClick={saveSnippet} variant="outline" size="sm">
                  <Save className="h-4 w-4 mr-2" />
                  Save
                </Button>
              </div>

              <Textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Describe what code you want to generate..."
                className="min-h-[80px]"
              />

              <div className="flex gap-2">
                <Button onClick={generateCode} disabled={isGenerating || !prompt.trim()}>
                  {isGenerating ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Wand2 className="h-4 w-4 mr-2" />
                  )}
                  Generate Code
                </Button>
                <Button onClick={debugCode} variant="outline" disabled={isDebugging || !code.trim()}>
                  {isDebugging ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Bug className="h-4 w-4 mr-2" />}
                  Debug
                </Button>
              </div>
            </div>
          </Card>

          <Tabs defaultValue="code">
            <TabsList>
              <TabsTrigger value="code">Code</TabsTrigger>
              <TabsTrigger value="output">Output</TabsTrigger>
            </TabsList>

            <TabsContent value="code" className="mt-2">
              <Textarea
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="Your code will appear here..."
                className="min-h-[400px] font-mono text-sm"
              />
            </TabsContent>

            <TabsContent value="output" className="mt-2">
              <Card className="p-4 min-h-[400px]">
                <pre className="whitespace-pre-wrap text-sm">{output || "Output will appear here..."}</pre>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
