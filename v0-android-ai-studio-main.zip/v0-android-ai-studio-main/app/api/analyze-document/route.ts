import { generateText } from "ai"

export const runtime = "nodejs"

export async function POST(req: Request) {
  const { text, analysisType, model } = await req.json()

  const prompts: Record<string, string> = {
    summary: "Provide a comprehensive summary of this document, highlighting key points and main ideas.",
    sentiment:
      "Analyze the sentiment and tone of this text. Is it positive, negative, or neutral? Provide specific examples.",
    keywords: "Extract the main keywords and key phrases from this document. List them in order of importance.",
    questions: "Generate relevant questions that this document answers. Format as a Q&A.",
  }

  const result = await generateText({
    model: model || "openai/gpt-4o-mini",
    messages: [
      { role: "system", content: "You are an expert document analyst." },
      { role: "user", content: `${prompts[analysisType]}\n\nDocument:\n${text}` },
    ],
    temperature: 0.5,
  })

  return Response.json({ analysis: result.text })
}
