import { generateText } from "ai"

export const runtime = "nodejs"

export async function POST(req: Request) {
  const { code, language, error, model } = await req.json()

  const prompt = `Debug this ${language} code. ${error ? `Error: ${error}` : "Find potential bugs and suggest improvements."}\n\n\`\`\`${language}\n${code}\n\`\`\``

  const result = await generateText({
    model: model || "openai/gpt-4o-mini",
    messages: [
      {
        role: "system",
        content:
          "You are an expert debugger. Analyze code, identify issues, and provide clear fixes with explanations.",
      },
      { role: "user", content: prompt },
    ],
    temperature: 0.3,
  })

  return Response.json({ analysis: result.text })
}
