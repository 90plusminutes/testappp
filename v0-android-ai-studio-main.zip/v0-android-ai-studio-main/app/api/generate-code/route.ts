import { generateText } from "ai"

export const runtime = "nodejs"

export async function POST(req: Request) {
  const { prompt, language, model } = await req.json()

  const systemPrompt = `You are an expert programmer. Generate clean, well-documented ${language} code based on the user's request. Only output the code, no explanations unless asked.`

  const result = await generateText({
    model: model || "openai/gpt-4o-mini",
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: prompt },
    ],
    temperature: 0.3,
  })

  return Response.json({ code: result.text })
}
