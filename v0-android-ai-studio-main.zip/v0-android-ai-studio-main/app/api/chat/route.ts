import { streamText } from "ai"

export const runtime = "nodejs"

export async function POST(req: Request) {
  const { messages, model } = await req.json()

  const result = streamText({
    model: model || "openai/gpt-4o-mini",
    messages,
    temperature: 0.7,
  })

  return result.toUIMessageStreamResponse()
}
