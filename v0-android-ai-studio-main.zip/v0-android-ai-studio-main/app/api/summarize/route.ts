import { generateText } from "ai"

export const runtime = "nodejs"

export async function POST(req: Request) {
  const { text, model } = await req.json()

  const result = await generateText({
    model: model || "openai/gpt-4o-mini",
    messages: [
      {
        role: "system",
        content: "You are an expert at summarizing documents. Create clear, concise summaries that capture key points.",
      },
      { role: "user", content: `Summarize this text:\n\n${text}` },
    ],
    temperature: 0.5,
  })

  return Response.json({ summary: result.text })
}
