"use client"

import { useState, useEffect } from "react"
import { Sidebar } from "@/components/sidebar"
import { ChatInterface } from "@/components/chat-interface"
import { CodeEditor } from "@/components/code-editor"
import { AITools } from "@/components/ai-tools"
import { WorkflowBuilder } from "@/components/workflow-builder"
import { SettingsPanel } from "@/components/settings-panel"
import { Toaster } from "@/components/ui/toaster"
import { storage } from "@/lib/storage"
import type { Chat } from "@/lib/types"

export default function Home() {
  const [activeView, setActiveView] = useState("chat")
  const [chats, setChats] = useState<Chat[]>([])
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null)

  useEffect(() => {
    setChats(storage.getChats())
  }, [])

  const createNewChat = () => {
    const newChat: Chat = {
      id: Date.now().toString(),
      title: "New Chat",
      messages: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    }
    storage.saveChat(newChat)
    setChats(storage.getChats())
    setSelectedChatId(newChat.id)
  }

  const handleSelectChat = (id: string) => {
    setSelectedChatId(id)
  }

  const handleDeleteChat = (id: string) => {
    storage.deleteChat(id)
    setChats(storage.getChats())
    if (selectedChatId === id) {
      setSelectedChatId(null)
    }
  }

  const handleMessagesChange = (messages: any[]) => {
    if (!selectedChatId) return

    const chat = chats.find((c) => c.id === selectedChatId)
    if (!chat) return

    const updatedChat: Chat = {
      ...chat,
      messages,
      updatedAt: new Date(),
      title: messages[0]?.content.slice(0, 50) || "New Chat",
    }

    storage.saveChat(updatedChat)
    setChats(storage.getChats())
  }

  const selectedChat = chats.find((c) => c.id === selectedChatId)

  return (
    <>
      <div className="flex h-screen bg-background">
        <div className="w-64 shrink-0">
          <Sidebar
            activeView={activeView}
            onViewChange={setActiveView}
            chats={chats}
            onNewChat={createNewChat}
            onSelectChat={handleSelectChat}
            onDeleteChat={handleDeleteChat}
            selectedChatId={selectedChatId}
          />
        </div>
        <div className="flex-1 overflow-hidden">
          {activeView === "chat" && (
            <ChatInterface
              chatId={selectedChatId}
              initialMessages={selectedChat?.messages || []}
              onMessagesChange={handleMessagesChange}
            />
          )}
          {activeView === "code" && <CodeEditor />}
          {activeView === "tools" && <AITools />}
          {activeView === "workflow" && <WorkflowBuilder />}
          {activeView === "settings" && <SettingsPanel />}
        </div>
      </div>
      <Toaster />
    </>
  )
}
